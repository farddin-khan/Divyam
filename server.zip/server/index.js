import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import Razorpay from 'razorpay';
import { createClient } from '@supabase/supabase-js';
import { sendShiprocketOrder } from './shiprocket.js';
import crypto from 'crypto';
import nodemailer from 'nodemailer';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config({ path: path.resolve(__dirname, '../.env') });
dotenv.config({ path: path.resolve(__dirname, '.env'), override: true });
dotenv.config();

const app = express();
const port = process.env.PORT || 4000;
const REVIEW_APPROVAL_EMAIL = 'farddinkhan18@gmail.com';

app.use(cors({ origin: process.env.CLIENT_ORIGIN || '*' }));
app.use(express.json());

const shiprocketRouter = express.Router();

if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
  console.warn('Razorpay credentials are missing in server environment.');
}

if (!process.env.VITE_SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
  console.warn('Supabase service role configuration is missing in server environment.');
}

if (!process.env.ADMIN_SECRET) {
  console.warn('Admin secret is not configured. Admin product creation requires ADMIN_SECRET.');
}

if (!process.env.ADMIN_USER_ID) {
  console.warn('Admin user id is not configured. Admin panel can still use ADMIN_SECRET only.');
}

let razorpay = null;
let supabase = null;

const missingRazorpayEnv = [];
if (!process.env.RAZORPAY_KEY_ID) missingRazorpayEnv.push('RAZORPAY_KEY_ID');
if (!process.env.RAZORPAY_KEY_SECRET) missingRazorpayEnv.push('RAZORPAY_KEY_SECRET');

if (missingRazorpayEnv.length > 0) {
  console.warn('Razorpay payment endpoints are disabled. Missing:', missingRazorpayEnv.join(', '));
} else {
  razorpay = new Razorpay({
    key_id: process.env.RAZORPAY_KEY_ID,
    key_secret: process.env.RAZORPAY_KEY_SECRET,
  });
}

const missingSupabaseEnv = [];
if (!process.env.VITE_SUPABASE_URL) missingSupabaseEnv.push('VITE_SUPABASE_URL');
if (!process.env.SUPABASE_SERVICE_ROLE_KEY) missingSupabaseEnv.push('SUPABASE_SERVICE_ROLE_KEY');

if (missingSupabaseEnv.length > 0) {
  console.error('Supabase-backed endpoints are disabled. Missing:', missingSupabaseEnv.join(', '));
} else {
  supabase = createClient(process.env.VITE_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
}

let mailTransporter = null;
if (process.env.SMTP_HOST && process.env.SMTP_PORT && process.env.SMTP_USER && process.env.SMTP_PASS) {
  mailTransporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT),
    secure: process.env.SMTP_PORT === '465',
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });

  mailTransporter.verify((error) => {
    if (error) {
      console.error('SMTP Error:', error);
    } else {
      console.log('SMTP Server is ready.');
    }
  });
} else {
  console.warn('SMTP configuration is missing; review approval emails will not be sent.');
}

function escapeHtml(value = '') {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function getAdminCredentials() {
  return {
    userId: String(process.env.ADMIN_USER_ID || 'admin').trim(),
    secret: String(process.env.ADMIN_SECRET || 'admin').trim(),
  };
}

function adminAccessGranted(secret, userId) {
  const adminCredentials = getAdminCredentials();
  const submittedSecret = String(secret || '').trim();
  const submittedUserId = String(userId || '').trim();

  if (submittedSecret !== adminCredentials.secret) {
    return false;
  }

  if (submittedUserId !== adminCredentials.userId) {
    return false;
  }

  return true;
}

async function attachOrderItems(orders) {
  if (!orders?.length) {
    return [];
  }

  const orderIds = orders.map((order) => order.id).filter(Boolean);
  if (!orderIds.length) {
    return orders.map((order) => ({ ...order, items: [] }));
  }

  const { data: items, error } = await supabase
    .from('order_items')
    .select('*')
    .in('order_id', orderIds);

  if (error) {
    console.warn('Unable to load order items:', error.message);
    return orders.map((order) => ({ ...order, items: [] }));
  }

  const groupedItems = (items || []).reduce((acc, item) => {
    const key = String(item.order_id);
    acc[key] = acc[key] || [];
    acc[key].push(item);
    return acc;
  }, {});

  return orders.map((order) => ({
    ...order,
    items: groupedItems[String(order.id)] || [],
  }));
}
app.post('/api/payment/create-order', async (req, res) => {
  try {
    if (!razorpay || !supabase) {
      return res.status(500).json({ error: 'Server configuration is invalid. Check API env variables.' });
    }

    const { formData, cartItems, shipping, total, selectedPaymentMethod, sessionId } = req.body;

    if (!formData || !cartItems || cartItems.length === 0) {
      return res.status(400).json({ error: 'Missing order details.' });
    }

    const { data: orderData, error: orderError } = await supabase
      .from('orders')
      .insert({
        session_id: sessionId,
        total_amount: total,
        customer_email: formData.email,
        customer_name: `${formData.firstName} ${formData.lastName}`,
        customer_phone: formData.phone,
        shipping_address: {
          address: formData.address,
          city: formData.city,
          state: formData.state,
          zip: formData.zip,
        },
        notes: formData.notes,
        payment_method: selectedPaymentMethod,
        payment_status: 'pending',
      })
      .select()
      .single();

    if (orderError) {
      throw orderError;
    }

    const razorpayOrder = await razorpay.orders.create({
      amount: Math.round(total * 100),
      currency: 'INR',
      receipt: `order_${orderData.id}`,
      payment_capture: 1,
    });

    await supabase
      .from('orders')
      .update({ razorpay_order_id: razorpayOrder.id })
      .eq('id', orderData.id);

    return res.json({
      orderId: razorpayOrder.id,
      amount: razorpayOrder.amount,
      currency: razorpayOrder.currency,
      keyId: process.env.RAZORPAY_KEY_ID,
      orderDbId: orderData.id,
    });
  } catch (error) {
    console.error('create-order error:', error);
    return res.status(500).json({ error: error.message || 'Unable to create Razorpay order.' });
  }
});

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.post('/api/reviews/request-approval', async (req, res) => {
  try {
    const {
      name = 'Anonymous',
      rating,
      text,
      product = 'Divyam product',
      location = 'India',
      timestamp,
    } = req.body;

    if (!rating || !text) {
      return res.status(400).json({
        success: false,
        error: 'Rating and review text are required.',
      });
    }

    if (!mailTransporter) {
      console.warn('Review approval email skipped because SMTP is not configured.');
      return res.status(500).json({
        success: false,
        emailSent: false,
        error: 'SMTP is not configured. Please check server environment variables.',
      });
    }

    const submittedAt = timestamp
      ? new Date(timestamp).toLocaleString('en-IN')
      : new Date().toLocaleString('en-IN');

    const subject = `New review approval request from ${name}`;
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 640px; margin: 0 auto; color: #111827;">
        <h2 style="margin: 0 0 8px; font-size: 24px;">New Review Submitted</h2>
        <p style="margin: 0 0 22px; color: #6b7280; line-height: 1.6;">
          A customer has submitted a new review. Please check and approve it from admin mode.
        </p>

        <div style="padding: 20px; border: 1px solid #e5e7eb; border-radius: 14px; background: #f9fafb;">
          <p><strong>Name:</strong> ${escapeHtml(name)}</p>
          <p><strong>Location:</strong> ${escapeHtml(location)}</p>
          <p><strong>Product:</strong> ${escapeHtml(product)}</p>
          <p><strong>Rating:</strong> ${escapeHtml(rating)} / 5</p>
          <p><strong>Submitted At:</strong> ${escapeHtml(submittedAt)}</p>
          <p><strong>Review:</strong></p>
          <p style="line-height: 1.7;">${escapeHtml(text)}</p>
        </div>

        <p style="margin-top: 22px; color: #374151;">
          Open your website with <strong>?admin=1</strong> to approve this review.
        </p>
      </div>
    `;

    await mailTransporter.sendMail({
      from: `"Divyam Reviews" <${process.env.SMTP_USER}>`,
      to: REVIEW_APPROVAL_EMAIL,
      subject,
      html,
    });

    return res.json({
      success: true,
      emailSent: true,
      message: `Approval email sent to ${REVIEW_APPROVAL_EMAIL}.`,
    });
  } catch (error) {
    console.error('Review Email Error:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Unable to send approval email.',
    });
  }
});
shiprocketRouter.get('/collections', async (req, res) => {
  try {
    if (!supabase) {
      return res.status(500).json({ error: 'Server configuration is invalid. Check API env variables.' });
    }

    const { data: categories, error } = await supabase.from('categories').select('*').order('sort_order', { ascending: true });
    if (error) {
      throw error;
    }

    const collections = (categories || []).map((collection) => ({
      id: collection.id,
      updated_at: collection.updated_at,
      body_html: collection.description || '',
      handle: collection.slug,
      image: { src: collection.image_url || null },
      title: collection.name,
      created_at: collection.created_at,
    }));

    return res.json({ data: { total: collections.length, collections } });
  } catch (error) {
    console.error('shiprocket-collections error:', error);
    return res.status(500).json({ error: error.message || 'Unable to fetch collections.' });
  }
});

shiprocketRouter.get('/products', async (req, res) => {
  try {
    if (!supabase) {
      return res.status(500).json({ error: 'Server configuration is invalid. Check API env variables.' });
    }

    const { data: products, error } = await supabase
      .from('products')
      .select('*, category:categories(*)')
      .order('created_at', { ascending: false });
    if (error) {
      throw error;
    }

    const mappedProducts = (products || []).map((product) => ({
      id: product.id,
      updated_at: product.updated_at,
      body_html: product.description || '',
      handle: product.slug,
      image: { src: Array.isArray(product.images) ? product.images[0] : null },
      title: product.name,
      created_at: product.created_at,
      collection_handle: product.category?.slug || null,
      collection_title: product.category?.name || null,
    }));

    return res.json({ data: { total: mappedProducts.length, products: mappedProducts } });
  } catch (error) {
    console.error('shiprocket-products error:', error);
    return res.status(500).json({ error: error.message || 'Unable to fetch products.' });
  }
});

shiprocketRouter.get('/collection-products', async (req, res) => {
  try {
    if (!supabase) {
      return res.status(500).json({ error: 'Server configuration is invalid. Check API env variables.' });
    }

    const { collection_id } = req.query;
    if (!collection_id) {
      return res.status(400).json({ error: 'collection_id query parameter is required.' });
    }

    const { data: category, error: categoryError } = await supabase
      .from('categories')
      .select('*')
      .or(`slug.eq.${collection_id},name.eq.${collection_id},id.eq.${collection_id}`)
      .single();

    if (categoryError || !category) {
      return res.status(404).json({ error: 'Collection not found.' });
    }

    const { data: products, error: productsError } = await supabase
      .from('products')
      .select('*, category:categories(*)')
      .eq('category_id', category.id)
      .order('created_at', { ascending: false });

    if (productsError) {
      throw productsError;
    }

    const mappedProducts = (products || []).map((product) => ({
      id: product.id,
      updated_at: product.updated_at,
      body_html: product.description || '',
      handle: product.slug,
      image: { src: Array.isArray(product.images) ? product.images[0] : null },
      title: product.name,
      created_at: product.created_at,
      collection_handle: product.category?.slug || null,
      collection_title: product.category?.name || null,
    }));

    return res.json({ data: { total: mappedProducts.length, products: mappedProducts } });
  } catch (error) {
    console.error('shiprocket-collection-products error:', error);
    return res.status(500).json({ error: error.message || 'Unable to fetch collection products.' });
  }
});

app.use('/api/products/shiprocket', shiprocketRouter);

app.get('/api/collections', async (req, res) => {
  try {
    if (!supabase) {
      return res.status(500).json({ error: 'Server configuration is invalid. Check API env variables.' });
    }

    const { data, error } = await supabase.from('categories').select('*').order('sort_order', { ascending: true });
    if (error) {
      throw error;
    }

    return res.json({ collections: data || [] });
  } catch (error) {
    console.error('get-collections error:', error);
    return res.status(500).json({ error: error.message || 'Unable to fetch collections.' });
  }
});

app.get('/api/collections/:slug/products', async (req, res) => {
  try {
    if (!supabase) {
      return res.status(500).json({ error: 'Server configuration is invalid. Check API env variables.' });
    }

    const { slug } = req.params;
    const { data: category, error: categoryError } = await supabase
      .from('categories')
      .select('id')
      .eq('slug', slug)
      .single();

    if (categoryError || !category) {
      return res.status(404).json({ error: 'Collection not found.' });
    }

    const { data, error } = await supabase
      .from('products')
      .select('*, category:categories(*)')
      .eq('category_id', category.id)
      .order('created_at', { ascending: false });

    if (error) {
      throw error;
    }

    return res.json({ products: data || [] });
  } catch (error) {
    console.error('get-products-by-collection error:', error);
    return res.status(500).json({ error: error.message || 'Unable to fetch products for collection.' });
  }
});

app.get('/api/products', async (req, res) => {
  try {
    if (!supabase) {
      return res.status(500).json({ error: 'Server configuration is invalid. Check API env variables.' });
    }

    const { category, featured, bestSeller, newArrival, search, limit, offset } = req.query;
    let query = supabase.from('products').select('*, category:categories(*)');

    if (category) {
      query = query.eq('category_id', category);
    }
    if (featured === 'true') {
      query = query.eq('featured', true);
    }
    if (bestSeller === 'true') {
      query = query.eq('best_seller', true);
    }
    if (newArrival === 'true') {
      query = query.eq('new_arrival', true);
    }
    if (search) {
      query = query.ilike('name', `%${search}%`);
    }

    if (limit) {
      query = query.limit(Number(limit));
    }
    if (offset) {
      query = query.range(Number(offset), Number(offset) + (Number(limit) || 19));
    }

    const { data, error } = await query.order('created_at', { ascending: false });
    if (error) {
      throw error;
    }

    return res.json({ products: data || [] });
  } catch (error) {
    console.error('get-products error:', error);
    return res.status(500).json({ error: error.message || 'Unable to fetch products.' });
  }
});

app.get('/api/products/:slug', async (req, res) => {
  try {
    if (!supabase) {
      return res.status(500).json({ error: 'Server configuration is invalid. Check API env variables.' });
    }

    const { slug } = req.params;
    const { data, error } = await supabase
      .from('products')
      .select('*, category:categories(*), reviews(*)')
      .eq('slug', slug)
      .single();

    if (error) {
      if (error.code === 'PGRST116' || error.code === 'PGRST117') {
        return res.status(404).json({ error: 'Product not found.' });
      }
      throw error;
    }

    return res.json({ product: data });
  } catch (error) {
    console.error('get-product-by-slug error:', error);
    return res.status(500).json({ error: error.message || 'Unable to fetch product.' });
  }
});

app.get('/api/admin/validate', (req, res) => {
  return res.json({
    ok: true,
    route: '/api/admin/validate',
    method: 'POST required for login',
    adminUserConfigured: Boolean(process.env.ADMIN_USER_ID),
    adminSecretConfigured: Boolean(process.env.ADMIN_SECRET),
  });
});

app.post('/api/admin/validate', (req, res) => {
  const { secret, userId } = req.body;

  if (!adminAccessGranted(secret, userId)) {
    return res.status(403).json({ valid: false, error: 'Invalid admin credentials. Use the ADMIN_USER_ID and ADMIN_SECRET from your active .env file.' });
  }

  return res.json({ valid: true, userId: getAdminCredentials().userId });
});

app.get('/api/admin/categories', async (req, res) => {
  try {
    if (!supabase) {
      return res.status(500).json({ error: 'Server configuration is invalid. Check API env variables.' });
    }

    const { data, error } = await supabase.from('categories').select('id, name, slug').order('sort_order', { ascending: true });
    if (error) {
      throw error;
    }

    return res.json({ categories: data || [] });
  } catch (error) {
    console.error('get-admin-categories error:', error);
    return res.status(500).json({ error: error.message || 'Unable to fetch categories.' });
  }
});

app.post('/api/admin/products', async (req, res) => {
  try {
    if (!supabase) {
      return res.status(500).json({ error: 'Server configuration is invalid. Check API env variables.' });
    }

    const { secret, userId, product } = req.body;
    if (!adminAccessGranted(secret, userId)) {
      return res.status(403).json({ error: 'Unauthorized.' });
    }

    if (!product || !product.name || !product.slug || !product.price) {
      return res.status(400).json({ error: 'Product name, slug, and price are required.' });
    }

    const imageArray = Array.isArray(product.images)
      ? product.images
      : typeof product.images === 'string'
      ? product.images.split(',').map((item) => item.trim()).filter(Boolean)
      : [];

    const benefitArray = Array.isArray(product.benefits)
      ? product.benefits
      : typeof product.benefits === 'string'
      ? product.benefits.split(',').map((item) => item.trim()).filter(Boolean)
      : [];

    const insertPayload = {
      name: product.name,
      slug: product.slug,
      description: product.description || '',
      short_description: product.short_description || '',
      price: Number(product.price) || 0,
      compare_price: product.compare_price ? Number(product.compare_price) : null,
      sku: product.sku || null,
      stock_quantity: product.stock_quantity ? Number(product.stock_quantity) : 0,
      weight: product.weight || null,
      category_id: product.category_id ? Number(product.category_id) : null,
      images: imageArray,
      featured: Boolean(product.featured),
      best_seller: Boolean(product.best_seller),
      new_arrival: Boolean(product.new_arrival),
      ingredients: product.ingredients || null,
      how_to_use: product.how_to_use || null,
      benefits: benefitArray,
      meta_title: product.meta_title || null,
      meta_description: product.meta_description || null,
      updated_at: new Date().toISOString(),
    };

    const { data, error } = await supabase.from('products').insert(insertPayload).select().single();
    if (error) {
      throw error;
    }

    return res.json({ product: data });
  } catch (error) {
    console.error('admin-create-product error:', error);
    return res.status(500).json({ error: error.message || 'Unable to create product.' });
  }
});

app.get('/api/admin/orders', async (req, res) => {
  try {
    if (!supabase) {
      return res.status(500).json({ error: 'Server configuration is invalid. Check API env variables.' });
    }

    const { secret, userId } = req.query;
    if (!adminAccessGranted(secret, userId)) {
      return res.status(403).json({ error: 'Unauthorized.' });
    }

    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(150);

    if (error) {
      throw error;
    }

    const orders = await attachOrderItems(data || []);
    return res.json({ orders });
  } catch (error) {
    console.error('admin-get-orders error:', error);
    return res.status(500).json({ error: error.message || 'Unable to fetch orders.' });
  }
});

app.post('/api/admin/orders', async (req, res) => {
  try {
    if (!supabase) {
      return res.status(500).json({ error: 'Server configuration is invalid. Check API env variables.' });
    }

    const { secret, userId, order } = req.body;
    if (!adminAccessGranted(secret, userId)) {
      return res.status(403).json({ error: 'Unauthorized.' });
    }

    if (!order?.customer_name || !order?.customer_phone || !order?.total_amount) {
      return res.status(400).json({ error: 'Customer name, phone, and total amount are required.' });
    }

    const insertPayload = {
      session_id: `manual-${Date.now()}`,
      total_amount: Number(order.total_amount) || 0,
      customer_email: order.customer_email || null,
      customer_name: order.customer_name,
      customer_phone: order.customer_phone,
      shipping_address: {
        address: order.address || '',
        city: order.city || '',
        state: order.state || '',
        zip: order.zip || '',
      },
      notes: order.notes || '',
      payment_method: order.payment_method || 'manual',
      payment_status: order.payment_status || 'pending',
      shiprocket_order_id: order.shiprocket_order_id || null,
      shiprocket_status: order.shiprocket_status || 'created',
    };

    const { data: orderData, error: orderError } = await supabase
      .from('orders')
      .insert(insertPayload)
      .select()
      .single();

    if (orderError) {
      throw orderError;
    }

    const itemPayload = (order.items || [])
      .filter((item) => item.product_name)
      .map((item) => ({
        order_id: orderData.id,
        product_id: item.product_id || null,
        product_name: item.product_name,
        product_price: Number(item.product_price) || 0,
        quantity: Number(item.quantity) || 1,
      }));

    if (itemPayload.length > 0) {
      const { error: itemsError } = await supabase.from('order_items').insert(itemPayload);
      if (itemsError) {
        console.warn('Manual order created but order items were not saved:', itemsError.message);
      }
    }

    const [createdOrder] = await attachOrderItems([orderData]);
    return res.json({ order: createdOrder });
  } catch (error) {
    console.error('admin-create-order error:', error);
    return res.status(500).json({ error: error.message || 'Unable to create order.' });
  }
});

app.patch('/api/admin/orders/:id/tracking', async (req, res) => {
  try {
    if (!supabase) {
      return res.status(500).json({ error: 'Server configuration is invalid. Check API env variables.' });
    }

    const { secret, userId, updates = {} } = req.body;
    if (!adminAccessGranted(secret, userId)) {
      return res.status(403).json({ error: 'Unauthorized.' });
    }

    const updatePayload = {};
    if (updates.payment_status !== undefined) updatePayload.payment_status = updates.payment_status;
    if (updates.shiprocket_status !== undefined) updatePayload.shiprocket_status = updates.shiprocket_status;
    if (updates.shiprocket_order_id !== undefined) updatePayload.shiprocket_order_id = updates.shiprocket_order_id || null;
    if (updates.notes !== undefined) updatePayload.notes = updates.notes || '';

    if (Object.keys(updatePayload).length === 0) {
      return res.status(400).json({ error: 'No tracking update provided.' });
    }

    const { data, error } = await supabase
      .from('orders')
      .update(updatePayload)
      .eq('id', req.params.id)
      .select()
      .single();

    if (error) {
      throw error;
    }

    const [order] = await attachOrderItems([data]);
    return res.json({ order });
  } catch (error) {
    console.error('admin-update-order-tracking error:', error);
    return res.status(500).json({ error: error.message || 'Unable to update order tracking.' });
  }
});

app.delete('/api/admin/orders/:id', async (req, res) => {
  try {
    if (!supabase) {
      return res.status(500).json({ error: 'Server configuration is invalid. Check API env variables.' });
    }

    const { secret, userId } = req.body;
    if (!adminAccessGranted(secret, userId)) {
      return res.status(403).json({ error: 'Unauthorized.' });
    }

    await supabase.from('order_items').delete().eq('order_id', req.params.id);

    const { error } = await supabase
      .from('orders')
      .delete()
      .eq('id', req.params.id);

    if (error) {
      throw error;
    }

    return res.json({ success: true });
  } catch (error) {
    console.error('admin-delete-order error:', error);
    return res.status(500).json({ error: error.message || 'Unable to delete order.' });
  }
});

app.get('/api/orders/track', async (req, res) => {
  try {
    if (!supabase) {
      return res.status(500).json({ error: 'Server configuration is invalid. Check API env variables.' });
    }

    const { orderId, phone } = req.query;
    if (!orderId || !phone) {
      return res.status(400).json({ error: 'Order ID and phone number are required.' });
    }

    const cleanOrderId = String(orderId).trim();
    const cleanPhone = String(phone).trim();

    let order = null;

    if (/^\d+$/.test(cleanOrderId)) {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .eq('id', Number(cleanOrderId))
        .eq('customer_phone', cleanPhone)
        .limit(1);

      if (error) {
        throw error;
      }

      order = data?.[0] || null;
    }

    if (!order) {
      const trackingFields = ['shiprocket_order_id', 'razorpay_order_id'];
      for (const field of trackingFields) {
        const { data, error } = await supabase
          .from('orders')
          .select('*')
          .eq(field, cleanOrderId)
          .eq('customer_phone', cleanPhone)
          .limit(1);

        if (error) {
          throw error;
        }

        if (data?.[0]) {
          order = data[0];
          break;
        }
      }
    }

    if (!order) {
      return res.status(404).json({ error: 'Order not found. Please check order ID and phone number.' });
    }

    const [orderWithItems] = await attachOrderItems([order]);
    return res.json({ order: orderWithItems });
  } catch (error) {
    console.error('track-order error:', error);
    return res.status(500).json({ error: error.message || 'Unable to track order.' });
  }
});

app.post('/api/payment/verify-payment', async (req, res) => {
  try {
    if (!razorpay || !supabase) {
      return res.status(500).json({ error: 'Server configuration is invalid. Check API env variables.' });
    }

    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      orderDbId,
      formData,
      cartItems,
      shipping,
      total,
      selectedPaymentMethod,
      sessionId,
    } = req.body;

    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature || !orderDbId) {
      return res.status(400).json({ error: 'Payment response is incomplete.' });
    }

    const generatedSignature = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest('hex');

    if (generatedSignature !== razorpay_signature) {
      return res.status(400).json({ error: 'Payment signature verification failed.' });
    }

    const { data: orderData, error: orderFetchError } = await supabase
      .from('orders')
      .select('*')
      .eq('id', orderDbId)
      .single();

    if (orderFetchError || !orderData) {
      throw orderFetchError || new Error('Order not found.');
    }

    const { error: orderUpdateError } = await supabase
      .from('orders')
      .update({
        payment_status: 'paid',
        payment_gateway: 'razorpay',
        razorpay_payment_id,
        razorpay_order_id,
      })
      .eq('id', orderData.id);

    if (orderUpdateError) {
      throw orderUpdateError;
    }

    const orderItems = cartItems.map((item) => ({
      order_id: orderData.id,
      product_id: item.product_id,
      product_name: item.product_name,
      product_price: item.product_price,
      quantity: item.quantity,
    }));

    const { error: itemsError } = await supabase.from('order_items').insert(orderItems);
    if (itemsError) {
      throw itemsError;
    }

    const shiprocketResponse = await sendShiprocketOrder(orderData, formData, cartItems, shipping, total);
    if (shiprocketResponse?.shiprocketOrderId) {
      await supabase
        .from('orders')
        .update({ shiprocket_order_id: shiprocketResponse.shiprocketOrderId, shiprocket_status: shiprocketResponse.status || 'created' })
        .eq('id', orderData.id);
    }

    return res.json({ success: true });
  } catch (error) {
    console.error('verify-payment error:', error);
    return res.status(500).json({ error: error.message || 'Payment verification failed.' });
  }
});

const clientDistPath = path.resolve(__dirname, '../dist');
app.use(express.static(clientDistPath));

app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'Endpoint not found', path: req.path });
  }

  return res.sendFile(path.join(clientDistPath, 'index.html'), (error) => {
    if (error) {
      next(error);
    }
  });
});

app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint not found', path: req.path });
});

app.listen(port, () => {
  console.log(`Payment API server listening on http://localhost:${port}`);
});
